def convertBytesToBits(byteAmount):
    return byteAmount*8
sUserBytes=raw_input("Enter byte amount to be converted to bits: ")
userBytes=int(sUserBytes)
bitAmount=convertBytesToBits(userBytes)
print ("%d bytes is %d bits"%(userBytes,bitAmount))
