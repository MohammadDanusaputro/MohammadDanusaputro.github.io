inF=open('Book1.csv','r')
outF=open('convertedData.csv','w')
columnNames=inF.readline()
outF.write(columnNames)
for l in inF:
    listRow=l.split(',')
    dollar=float(listRow[1])*float(listRow[2])
    formattedDollar="%.2f"%dollar
    l=l.replace('?',formattedDollar)
    print l
    outF.write(l)
inF.close()
outF.close()


    
    
