#open file
fo=open("students.csv","r+")
fo2=open("finalGrades.csv","w+")
for l in fo.readlines():
    print "This is a line read from the file as string :", l
    list=l.split(',') #this converts the line into a list
    print "This is what the list looks like: ", list
    id=list[0] # here we store the students's id
    lab1=float(list[1]) # we convert string values to float data type
    lab2=float(list[2])
    lab3=float(list[3])
    finalLabScore=(lab1+lab2+lab3)/3.75
    finalProjectScore=float(list[4])*0.20
    finalSurveyScore=float(list[5])*0.05
    finalScore=finalLabScore+finalProjectScore+finalSurveyScore
    letterGrade="n/a"
    if finalScore>90:
        letterGrade="A"
    elif finalScore>80:
        letterGrade="B"
    elif finalScore>70:
        letterGrade="C"
    elif finalScore>55:
        letterGrade="D"
    else:
        letterGrade="F"
    line="%s, %.2f, %s\n" %(id,finalScore, letterGrade)
    print "This is the Students Id, Numerical Score, Letter Grade: ",line
    fo2.write(line)
    print "========================================"
#close opened file
fo.close()    
fo2.close() 
